import './Footer.css';

export default function Footer() {
  return (
    <footer>
      <div className="footer-content">
        <div className="social-links">
          <a href="#" aria-label="GitHub"><i className="fab fa-github"></i></a>
          <a href="#" aria-label="LinkedIn"><i className="fab fa-linkedin-in"></i></a>
        </div>
      </div>
      <div className="copyright">
        <p>&copy; 2025 Nathan Soto. All rights reserved.</p>
      </div>
    </footer>
  );
}
